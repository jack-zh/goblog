# siege -c 100 -r 100 -b http://127.0.0.1:8080

# wsgiref
'''
Transactions:		        9772 hits
Availability:		       97.72 %
Elapsed time:		      149.58 secs
Data transferred:	        0.11 MB
Response time:		        0.31 secs
Transaction rate:	       65.33 trans/sec
Throughput:		        0.00 MB/sec
Concurrency:		       20.51
Successful transactions:        9772
Failed transactions:	         228
Longest transaction:	       34.17
Shortest transaction:	        0.00
'''

# bjoern
'''
Transactions:		       10000 hits
Availability:		      100.00 %
Elapsed time:		        9.93 secs
Data transferred:	        0.11 MB
Response time:		        0.03 secs
Transaction rate:	     1007.05 trans/sec
Throughput:		        0.01 MB/sec
Concurrency:		       26.58
Successful transactions:       10000
Failed transactions:	           0
Longest transaction:	        0.32
Shortest transaction:	        0.00

'''

# tornado
'''
Transactions:		       10000 hits
Availability:		      100.00 %
Elapsed time:		       15.59 secs
Data transferred:	        0.11 MB
Response time:		        0.15 secs
Transaction rate:	      641.44 trans/sec
Throughput:		        0.01 MB/sec
Concurrency:		       95.41
Successful transactions:       10000
Failed transactions:	           0
Longest transaction:	        0.24
Shortest transaction:	        0.00
'''

# auto
'''
Transactions:		       10000 hits
Availability:		      100.00 %
Elapsed time:		       17.25 secs
Data transferred:	        0.11 MB
Response time:		        0.17 secs
Transaction rate:	      579.71 trans/sec
Throughput:		        0.01 MB/sec
Concurrency:		       96.82
Successful transactions:       10000
Failed transactions:	           0
Longest transaction:	        0.25
Shortest transaction:	        0.00

'''

# WaitressServer
'''
Transactions:		       10000 hits
Availability:		      100.00 %
Elapsed time:		       16.82 secs
Data transferred:	        0.11 MB
Response time:		        0.16 secs
Transaction rate:	      594.53 trans/sec
Throughput:		        0.01 MB/sec
Concurrency:		       96.47
Successful transactions:       10000
Failed transactions:	           0
Longest transaction:	        0.22
Shortest transaction:	        0.00
'''

# TwistedServer
'''
Transactions:		       10000 hits
Availability:		      100.00 %
Elapsed time:		       25.23 secs
Data transferred:	        0.11 MB
Response time:		        0.25 secs
Transaction rate:	      396.35 trans/sec
Throughput:		        0.00 MB/sec
Concurrency:		       98.23
Successful transactions:       10000
Failed transactions:	           0
Longest transaction:	        0.47
Shortest transaction:	        0.02
'''

# rocket
'''
Transactions:		       10000 hits
Availability:		      100.00 %
Elapsed time:		       15.58 secs
Data transferred:	        0.11 MB
Response time:		        0.15 secs
Transaction rate:	      641.85 trans/sec
Throughput:		        0.01 MB/sec
Concurrency:		       95.57
Successful transactions:       10000
Failed transactions:	           0
Longest transaction:	        0.24
Shortest transaction:	        0.00


'''

# pip install gevent-socketio
'''
Transactions:		       10000 hits
Availability:		      100.00 %
Elapsed time:		       14.66 secs
Data transferred:	        0.11 MB
Response time:		        0.14 secs
Transaction rate:	      682.13 trans/sec
Throughput:		        0.01 MB/sec
Concurrency:		       95.59
Successful transactions:       10000
Failed transactions:	           0
Longest transaction:	        0.28
Shortest transaction:	        0.00

'''

# ab -c 10000 -n 100
# wsgi
'''
Server Software:        Werkzeug/0.9.6
Server Hostname:        localhost
Server Port:            5000

Document Path:          /
Document Length:        12 bytes

Concurrency Level:      100
Time taken for tests:   12.757 seconds
Complete requests:      10000
Failed requests:        0
Write errors:           0
Total transferred:      1650000 bytes
HTML transferred:       120000 bytes
Requests per second:    783.90 [#/sec] (mean)
Time per request:       127.567 [ms] (mean)
Time per request:       1.276 [ms] (mean, across all concurrent requests)
Transfer rate:          126.31 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   3.5      0      41
Processing:    22  126  30.1    121     380
Waiting:        9  126  30.0    120     379
Total:         61  127  31.2    121     410

Percentage of the requests served within a certain time (ms)
  50%    121
  66%    122
  75%    122
  80%    123
  90%    130
  95%    132
  98%    264
  99%    340
 100%    410 (longest request)
 '''

# bjoern
'''
Server Software:        Werkzeug/0.9.6
Server Hostname:        localhost
Server Port:            5000

Document Path:          /
Document Length:        12 bytes

Concurrency Level:      100
Time taken for tests:   12.738 seconds
Complete requests:      10000
Failed requests:        0
Write errors:           0
Total transferred:      1650000 bytes
HTML transferred:       120000 bytes
Requests per second:    785.06 [#/sec] (mean)
Time per request:       127.379 [ms] (mean)
Time per request:       1.274 [ms] (mean, across all concurrent requests)
Transfer rate:          126.50 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   3.6      0      40
Processing:    22  126  29.2    121     368
Waiting:       22  126  29.1    120     367
Total:         60  127  30.3    121     391

Percentage of the requests served within a certain time (ms)
  50%    121
  66%    122
  75%    123
  80%    123
  90%    130
  95%    133
  98%    239
  99%    349
 100%    391 (longest request)

 '''
from bottle import route, run, template

@route('/')
def index():
    return "Hello, world"

run(host='localhost', port=8080)
