# siege -c 100 -r 100 -b http://127.0.0.1:5000/
'''
Transactions:		       10000 hits
Availability:		      100.00 %
Elapsed time:		       28.01 secs
Data transferred:	        0.11 MB
Response time:		        0.27 secs
Transaction rate:	      357.02 trans/sec
Throughput:		        0.00 MB/sec
Concurrency:		       98.06
Successful transactions:       10000
Failed transactions:	           0
Longest transaction:	        0.47
Shortest transaction:	        0.00
'''

# ab -n 10000-c 100
'''
Server Software:        Werkzeug/0.9.6
Server Hostname:        localhost
Server Port:            5000

Document Path:          /
Document Length:        12 bytes

Concurrency Level:      100
Time taken for tests:   12.685 seconds
Complete requests:      10000
Failed requests:        0
Write errors:           0
Total transferred:      1650000 bytes
HTML transferred:       120000 bytes
Requests per second:    788.32 [#/sec] (mean)
Time per request:       126.852 [ms] (mean)
Time per request:       1.269 [ms] (mean, across all concurrent requests)
Transfer rate:          127.02 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   2.7      0      39
Processing:    24  126  27.3    121     389
Waiting:       23  125  27.2    120     387
Total:         51  126  28.5    121     415

Percentage of the requests served within a certain time (ms)
  50%    121
  66%    122
  75%    122
  80%    122
  90%    130
  95%    133
  98%    223
  99%    328
 100%    415 (longest request)

 '''
from flask import Flask
app = Flask(__name__)

@app.route('/')
def hello_world():
    return 'Hello World!'

if __name__ == '__main__':
    app.run()


