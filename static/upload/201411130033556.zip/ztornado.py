# siege -c 100 -r 100 -b http://127.0.0.1:8888/
'''
Transactions:		       10000 hits
Availability:		      100.00 %
Elapsed time:		       22.98 secs
Data transferred:	        0.11 MB
Response time:		        0.22 secs
Transaction rate:	      435.16 trans/sec
Throughput:		        0.00 MB/sec
Concurrency:		       97.57
Successful transactions:       10000
Failed transactions:	           0
Longest transaction:	        0.28
Shortest transaction:	        0.01

'''
# ab -n 10000 -c 100
'''
Server Software:        TornadoServer/4.1.dev1
Server Hostname:        localhost
Server Port:            8888

Document Path:          /
Document Length:        12 bytes

Concurrency Level:      100
Time taken for tests:   11.245 seconds
Complete requests:      10000
Failed requests:        0
Write errors:           0
Total transferred:      2100000 bytes
HTML transferred:       120000 bytes
Requests per second:    889.30 [#/sec] (mean)
Time per request:       112.448 [ms] (mean)
Time per request:       1.124 [ms] (mean, across all concurrent requests)
Transfer rate:          182.38 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   2.7      0      41
Processing:    18  111  26.8    111     575
Waiting:       17  111  26.8    111     574
Total:         55  112  28.5    111     610

Percentage of the requests served within a certain time (ms)
  50%    111
  66%    112
  75%    113
  80%    114
  90%    120
  95%    123
  98%    141
  99%    212
 100%    610 (longest request)

'''
import tornado.ioloop
import tornado.web

class MainHandler(tornado.web.RequestHandler):
    def get(self):
        self.write("Hello, world")

application = tornado.web.Application([
    (r"/", MainHandler),
])

if __name__ == "__main__":
    application.listen(8888)
    tornado.ioloop.IOLoop.instance().start()
